NASA POWER — INDEPENDENT VERIFICATION EVIDENCE
Archive generated (UTC): 2026-11-03T21:05:05.837Z
Verification outcome: ALL VALUES MATCHED WITHIN TOLERANCE
Metric: T2M; period: 2000–2025; tolerance: ±0.01 in source metric units.

nasa-original-response.json is the original NASA POWER JSON response text captured during this same verification request (monthly and YYYY13 annual values).
annual-comparison.csv lists every annual difference and missing or mismatched observations.
website-values-used.csv contains the exact website annual values submitted for comparison (not a replacement for the original website export).
manifest.json records source URLs, timestamps, comparison status and SHA-256 digests of included evidence files.

WARNING: Agreement with NASA POWER gridded products does not prove ground-station accuracy, geographic coverage of an entire governorate, or causal climate trends.
NOTE: Precipitation aggregation and anomalous years require independent scientific interpretation even when values match.

العربية: يتضمن هذا الأرشيف استجابة ناسا الأصلية من عملية التحقق نفسها، وقيم الموقع، وجدول المطابقة، ووقت الفحص وبصمات SHA-256.
المطابقة تثبت اتفاق القيم مع بيانات ناسا الشبكية ضمن هامش المقارنة، ولا تعني التحقق من محطة أرصاد أو متوسط المحافظة.
عند ظهور قيم مختلفة أو مفقودة، تكون النتيجة: تتطلب المراجعة، وليست شهادة تطابق.
